/* This file is installed for backward compatibility. */
#include <gc/gc.h>
